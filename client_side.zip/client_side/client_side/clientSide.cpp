// Author : Dr. Foster
// edited by: Chelsea Carter, Olivia Wanless, and Elijsha Baetiong 
//Purpose: demonstration of winsock API using simple client
//Interfaces with Source (chatServer) programs
//Requires user input of username, local client server IP address, and port number //of local client server
//Prompts user for various other commands and message inputs
//  Citation : Based off of sample code found at https://www.binarytides.com/winsock-socket-programming-tutorial/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include <winsock2.h>
#include <WS2tcpip.h>

#pragma comment(lib,"ws2_32.lib") //Winsock Library - don't touch this.
char * convertTo3ByteString(char[]);

char LOCALIPADDR[22];
char REMOTEIPADDR[22];
#define MSGRECVLENGTH 168
char msgRecv[MSGRECVLENGTH + 1];

using namespace std;

// create some constants for error codes if the program dies...
#define ERROR_WINSOCK_INIT_FAILURE				1;
#define ERROR_WINSOCK_SOCKET_CREATE_FAILURE		2;
#define ERROR_WINSOCK_SOCKET_CONNECT_FAILURE	3;
#define ERROR_WINSOCK_SOCKET_SEND_FAILURE       4;
#define ERROR_WINSOCK_SOCKET_BIND_FAILURE       5;

struct sockaddr_in addrLocalServer, addrRemoteServer;    // IN_ADDR holds an IPv4 address
char * message;
char * l_ipv4addr, r_ipv4addr;
int remoteServerPortNum;

#define MAX_USERNAME_LENGTH 64

int main(int argc, char *argv[])
{
	int localServerPortNum;
	char c_remoteServerPortNum[20];
	char remoteServerUsername[MAX_USERNAME_LENGTH];
	char userCommand[5];
	char userName[MAX_USERNAME_LENGTH];
	char userMessage[161];
	int headerLength = 8;
	char c_headerLength[] = "008";
	char tempArray[4];
	char c_payloadLength[4];

	// Before using Winsock calls on Windows, the Winsock library needs to be initialized...
	WSADATA wsa;
	SOCKET localSocket, remoteSocket;

	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Winsock error Code : %d", WSAGetLastError());
		return ERROR_WINSOCK_INIT_FAILURE;
	}

	if (argc == 4)
	{
		//accepts client's username, and local server's IP address and port number
		strcpy(userName, argv[1]);
		strcpy(LOCALIPADDR, argv[2]);
		localServerPortNum = atoi(argv[3]);
	}
	else
	{
		printf("Enter the required arguments for the program to work\n");
		exit(0);
	}

	//  The socket() call takes three arguments. The first is the network protocol "Address Family", hence the AF_prefix.
	// The two most common are AF_INET for IPv4 and AF_INET6 for IPv6. The next asks for the port type, which is usually a
	// TCP port with SOCK_STREAM, or a UDP port with SOCK_DGRAM. The third parameter is the specific protocol, such as ICMP,
	// IGMP, or for the purposes of the program, TCP, which uses the constant IPPROTO_TCP. 

	if ((localSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET)
	{
		printf("Could not create local socket : %d", WSAGetLastError());
		return ERROR_WINSOCK_SOCKET_CREATE_FAILURE;
	}

	//setup configuration for local server
	l_ipv4addr = LOCALIPADDR;

	size_t newsize = strlen(LOCALIPADDR) + 1;
	WCHAR * l_ipv4addr = new WCHAR[newsize];
	size_t convertedChars = 0;
	mbstowcs_s(&convertedChars, l_ipv4addr, newsize, LOCALIPADDR, _TRUNCATE);

	InetPton(AF_INET, l_ipv4addr, &addrLocalServer.sin_addr.s_addr);  // There are useful functions to convert between formats,
	addrLocalServer.sin_family = AF_INET;							// Must agree with the socket Address Family type
	addrLocalServer.sin_port = htons(localServerPortNum);			// htons() converts the host endianness to network endianness
	// This should always be used when transmitting integers
	//Attempt to connect to local server
	if (connect(localSocket, (struct sockaddr *) &addrLocalServer, sizeof(addrLocalServer)) < 0)
	{
		printf("Could not connect socket to local server");
		return ERROR_WINSOCK_SOCKET_CONNECT_FAILURE;
	}
	else
	{
		//Connection to local server is successful
		// client sends "ILVU" message with no payload to local server
		char fullMessage[9];
		strcpy(fullMessage, c_headerLength);
		strcat(fullMessage, " ");
		strcat(fullMessage, "ILVU");
		if (send(localSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
		{
			printf("Error sending ILVU message to local server...");
			return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
		}
		// wait for response back from local server of type IKNW
		if (recv(localSocket, msgRecv, MSGRECVLENGTH, 0) > 0)
		{
			char messageType[5];
			char headerExtract[9];
			//extract the header from the message
			for (int i = 0; i < 8; i++)
			{
				headerExtract[i] = msgRecv[i];
			}

			for (int k = 4; k < 8; k++)
			{
				messageType[k - 4] = headerExtract[k];
			}

			if (strcmp(messageType, "IKNW") == 0)
			{
				//do nothing but receive it
			}
		}
	}

	while (1)
	{
		//Prompt user to enter "exit" or "open"
		printf("Enter \"exit\" to exit the program, or \"open\" to establish a connection to the remote server: ");
		//reads in the command enter by the remote server into 'userCommand' variable
		scanf("%s", userCommand);
		//if the command enter is equal to the string "exit"
		if (strcmp(userCommand, "exit") == 0)
		{
			//create an array of size headerLength size + 1 to fit the entire string
			char fullMessage[9];
			//concatenate the header and type (KYLO) 
			strcpy(fullMessage, c_headerLength);
			strcat(fullMessage, " ");
			strcat(fullMessage, "KYLO");
			//send the message to the local socket and exit the program if the message was sent successfully
			if (send(localSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
			{
				printf("Error sending KYLO message to local server...");
				return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
			}
			exit(0);
		}
		//if the command enter is equal to the string "open"
		else if (strcmp(userCommand, "open") == 0)
		{
			//prompt the user to enter in the IP address and port # of the remote server
			//scan each response to its appropriate variables as string and integer types
			printf("Enter Remote Server\'s IP Address: ");
			scanf("%s", REMOTEIPADDR);
			printf("Enter Remote Server\'s Port Number: ");
			scanf("%d", &remoteServerPortNum);

			//create remote socket
			if ((remoteSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET)
			{
				printf("Could not create remote socket : %d", WSAGetLastError());
				return ERROR_WINSOCK_SOCKET_CREATE_FAILURE;
			}

			//conversion to wide chars for r_ipv4addr variable
			size_t newsize = strlen(REMOTEIPADDR) + 1;
			WCHAR * r_ipv4addr = new WCHAR[newsize];
			size_t convertedChars = 0;
			mbstowcs_s(&convertedChars, r_ipv4addr, newsize, REMOTEIPADDR, _TRUNCATE);

			//Configure the remote socket with an IP address and port number
			InetPton(AF_INET, r_ipv4addr, &addrRemoteServer.sin_addr.s_addr);  // There are useful functions to convert between formats,
			addrRemoteServer.sin_family = AF_INET;							// Must agree with the socket Address Family type
			addrRemoteServer.sin_port = htons(remoteServerPortNum);			// htons() converts the host endianness to network endianness
			// This should always be used when transmitting integers

			inet_ntop(AF_INET, &(addrRemoteServer.sin_addr), (PSTR)r_ipv4addr, INET_ADDRSTRLEN);
			//attempt to connect to remote socket
			if (connect(remoteSocket, (struct sockaddr *) &addrRemoteServer, sizeof(addrRemoteServer)) < 0)
			{
				printf("Could not connect socket to remote server");
				return ERROR_WINSOCK_SOCKET_CONNECT_FAILURE;
			}
			else
			{
				//the connection to the remote socket was successful
				//send USER message type with name of the user as payload
				int payloadLength = strlen(userName);
				int totalpayloadLength = headerLength + payloadLength;
				//convert length to ascii
				sprintf(c_payloadLength, "%d", totalpayloadLength);
				char *pTempArray = convertTo3ByteString(c_payloadLength);
				//send message of type USER to the remote socket
				char fullMessage[169];
				//concatenate the formatted header length string with the type USER and userName string
				strcpy(fullMessage, pTempArray);
				strcat(fullMessage, " ");
				strcat(fullMessage, "USER");
				strcat(fullMessage, userName);
				//sends the USER type message to the remote socket
				if (send(remoteSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
				{
					printf("Error sending USER message");
					return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
				}
				//wait for response back from remote server of ACPT type
				if (recv(remoteSocket, msgRecv, MSGRECVLENGTH, 0) > 0)
				{
					char c_payloadLength[4];
					char messageType[5];
					char payload[161];
					char headerExtract[9];

					for (int i = 0; i < 8; i++)
					{
						headerExtract[i] = msgRecv[i];
					}
					//extract the payload length as an ascii string
					for (int j = 0; j < 3; j++)
					{
						c_payloadLength[j] = headerExtract[j];
					}
					//convert payload length to integer
					int payloadLength = atoi(c_payloadLength);
					//extract message type from header
					for (int k = 4; k < 8; k++)
					{
						messageType[k - 4] = headerExtract[k];
					}
					//extracts payload data from msg
					for (int l = 8; l < payloadLength; l++)
					{
						payload[l - 8] = msgRecv[l];
					}

					//if the client receives a message of type ACPT, and the payload length is not greater than 64 bytes
					if (strncmp(messageType, "ACPT", 4) == 0 && (payloadLength - 8 <= 64))
					{
						strcpy(remoteServerUsername, payload);
					}
				}
				//continue to send messages as long as the user does not enter "quit"
				while (strcmp(userMessage, "quit\n") != 0)
				{
					//prints out only remote server's username (by only printing valid ASCII characters in the range of 0-255)
					int i = 0;
					while (remoteServerUsername[i]>0 && remoteServerUsername[i]<255)
					{
						cout << remoteServerUsername[i];
						i++;
					}
					//prints out necessary colon
					cout << ":";
					//reads userMessage from stdin with 160 character limit
					fgets(userMessage, 160, stdin);
					//use a variable to store userMessage length which will be added to the header size
					//then use the sprintf function to be able to "convert" from integer to ascii
					int payloadLength = strlen(userMessage);
					int totalpayloadLength = (headerLength + payloadLength);
					//convert length to ascii
					sprintf(c_payloadLength, "%d", totalpayloadLength);
					char *pTempArray = convertTo3ByteString(c_payloadLength);
					char fullMessage[169];
					//concatenates header length string with message type TEXT and message payload
					strcpy(fullMessage, pTempArray);
					strcat(fullMessage, " ");
					strcat(fullMessage, "TEXT");
					strcat(fullMessage, userMessage);
					// this message will then be sent over to both the local and remote servers (localSocket and remoteSocket)
					if (send(localSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
					{
						printf("Error sending messages to either local server or remote server...");
						return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
					}
					if (send(remoteSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
					{
						printf("Error sending messages to either local server or remote server...");
						return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
					}
				}

				//if the user types in "quit" as the message
				if (strcmp(userMessage, "quit\n") == 0)
				{
					//send QUIT type message to remote server
					char fullMessage[9];
					//concatenate the header with the message type QUIT
					strcpy(fullMessage, c_headerLength);
					strcat(fullMessage, " ");
					strcat(fullMessage, "QUIT");
					//send message to remote server
					if (send(remoteSocket, fullMessage, (int)strlen(fullMessage), 0) < 0)
					{
						printf("Error sending QUIT message to remote server...");
						return ERROR_WINSOCK_SOCKET_SEND_FAILURE;
					}
					///Prints out message to let user know that the connection has been closed
					printf("Connection to remote server ");
					int i = 0;
					while (remoteServerUsername[i]>0 && remoteServerUsername[i]<255)
					{
						cout << remoteServerUsername[i];
						i++;
					}

					printf(" has been closed.\n");
					//resets  userMessage
					memset(userMessage, 0, 160);
				}
			}
		}
		//exits program so that user can start over again with valid command
		else
		{
			printf("Please try again with a valid command\n");
			exit(0);
		}
	}

	WSACleanup();
	return 0;
}

//converts string to 3 byte length by adding leading zeros as necessary to get length of 3
char * convertTo3ByteString(char c_payloadLength[])
{
	int numOfBytes = strlen(c_payloadLength);
	char tempArray[4];
	switch (numOfBytes)
	{
		//if the num of bytes is 1, add two leading zeros to make it 3
		case 1:
			strcpy(tempArray, "00");
			strcat(tempArray, c_payloadLength);
			break;
		//if the num of bytes is 2, add 1 leading zero to make it 3
		case 2:
			strcpy(tempArray, "0");
			strcat(tempArray, c_payloadLength);
			break;
		//if the num of bytes is 3, copy string as is because it is already 3 bytes
		case 3:
			strcpy(tempArray, c_payloadLength);
			break;
	}
	return tempArray;
}
