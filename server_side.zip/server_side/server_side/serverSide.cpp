// Author : Dr. Foster
// edited by: Chelsea Carter, Olivia Wanless, and Elijsha Baetiong 
// Purpose : demonstration of winsock API using a simple server
//Interfaces with chatClient programs using multi threading
// Requires user input of username and optional port number  
//  Citation : Based off of sample code found at https://www.binarytides.com/winsock-socket-programming-tutorial/

#include <stdio.h>
#include <winsock2.h>
#include <WS2tcpip.h>
#include <string.h>
#include <process.h>  // Windows multithreading functions
#include <iostream>
#define KRED "\x1B[31m" 
char * convertTo3ByteString(char[]);


#pragma comment(lib,"ws2_32.lib") //Winsock Library - don't touch this line.

// create some constants for error codes if the program dies...
#define ERROR_WINSOCK_INIT_FAILURE				1;
#define ERROR_WINSOCK_SOCKET_CREATE_FAILURE		2;
#define ERROR_WINSOCK_SOCKET_CONNECT_FAILURE	3;
#define ERROR_WINSOCK_SOCKET_SEND_FAILURE       4;
#define ERROR_WINSOCK_SOCKET_BIND_FAILURE       5;

struct sockaddr_in addrServer, addrClient;   // sockets are used to access the network
WCHAR ipv4addr[INET_ADDRSTRLEN] = L"";  // hard-coded just to test functionality	

#define MSGRECVLENGTH 100


char userName[20];	
int portNum;
int upper = 50999;
int lower = 50000;
bool kylo = 0;
bool local = 0;
void socketMessages(void *s);

using namespace std;

int main(int argc, char *argv[])
{

	// Before using Winsock calls on Windows, the Winsock library needs to be initialized...
	WSADATA wsa;
	SOCKET s;
	SOCKET s_new;
	int c;
	if ((argc == 2) || (argc == 3 && !((atoi(argv[2]) >= 50000) && atoi(argv[2]) <= 50999))){
		strcpy(userName, argv[1]);
		portNum = (rand() % (upper - lower + 1)) + lower;
	}
	else if ((argc == 3 && (atoi(argv[2]) >= 50000) && atoi(argv[2]) <= 50999)){
		strcpy(userName, argv[1]);
		portNum = atoi(argv[2]);
	}
	else if (argc != 2 || argc != 3)
	{
		printf("%sThis program only accepts two forms.\n", KRED);
		printf("%sExample 1: ./chatserver Carter \n", KRED);
		printf("%sExample 2: ./chatserver Wanless 50000\n", KRED);
		exit(0);
	}

	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("Failed. Winsock error Code : %d", WSAGetLastError());
		return ERROR_WINSOCK_INIT_FAILURE;
	}

	/* The socket() call takes three arguments. The first is the network protocol "Address Family", hence the AF_prefix.
	The two most common are AF_INET for IPv4 and AF_INET6 for IPv6. The next asks for the port type, which is usually a
	TCP port with SOCK_STREAM, or a UDP port with SOCK_DGRAM. The third parameter is the specific protocol, such as ICMP,
	IGMP, or for the purposes of the program, TCP, which uses the constant IPPROTO_TCP. */

	if ((s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET)
	{
		printf("Could not create socket : %d", WSAGetLastError());
		return ERROR_WINSOCK_SOCKET_CREATE_FAILURE;
	}
	// Th socket now exists...but it isn't configured with an IP address or port number yet.

	// specify the IP address of the server 
	//InetPtonW(AF_INET, ipv4addr, &addrServer.sin_addr.s_addr);
	//or allow the system to select one
	addrServer.sin_addr.s_addr = INADDR_ANY;					// NOTE!!! when you use INADDR_ANY, the host will print 0.0.0.0 as the IP Address, but it is listening.
	addrServer.sin_family = AF_INET;							// Must agree with the socket Address Family type
	addrServer.sin_port = htons(portNum);							// htons() converts the host endianness to network endianness
	// This should always be used when transmitting integers
	// ntohs() converts the opposite way for receiving integers.

	if (bind(s, (struct sockaddr *) &addrServer, sizeof(addrServer)) == SOCKET_ERROR)
	{
		printf("Could not bind socket");
		return ERROR_WINSOCK_SOCKET_BIND_FAILURE;
	}
	// converts between the IP address as a number to a printable string in ipv4addr
	inet_ntop(AF_INET, &(addrServer.sin_addr), (PSTR)ipv4addr, INET_ADDRSTRLEN);
	printf("Listening on IP address %s port %d...\n", ipv4addr, ntohs(addrServer.sin_port));

	while (!kylo){
		listen(s, 5);  // tells socket to start listening for clients, 5 is the number of backlogged connections allowed

		c = sizeof(struct sockaddr_in);
		s_new = accept(s, (struct sockaddr *)&addrClient, &c);
		if (s_new == INVALID_SOCKET)
		{
			printf("Accept failed with error code : %d", WSAGetLastError());
		}
		inet_ntop(AF_INET, &(addrClient.sin_addr), (PSTR)ipv4addr, INET_ADDRSTRLEN);
		printf("Accepted a connection from IP address %s port %d...\n", ipv4addr, ntohs(addrClient.sin_port));

		_beginthread(socketMessages, 0, (void *)s_new);
	}


	closesocket(s);
	WSACleanup();
}

void socketMessages(void *s){

	SOCKET connection = SOCKET(s);	//turn it back into a socket
	int bytesRecv;					//initalize varibles
	char messageSize[4];			//three byte message size
	char messageType[5];			//for the message byte
	char message[160];
	char name[20];				//twenty string user name
	int msgSize = 0;
	int headerLength = 8;
	int payload = 0;
	int numOfBytes;
	char tempArray[4];
	char tempMessage[169];
	bool quit = 0;
	char msgRecv[169];


	while (!quit){
		bytesRecv = 0;
		memset(messageSize, 0, 3);
		memset(tempMessage, 0, 169);
		memset(msgRecv, 0, 169);
		memset(message, 0, 160);
		bytesRecv = recv(connection, tempMessage, MSGRECVLENGTH, 0); //Grab incoming message
		for (int i = 0; i < bytesRecv; i++){
			if (isprint(tempMessage[i])){
				msgRecv[i] = tempMessage[i];
			}
		}
		sscanf(tempMessage, "%s", messageSize); //scan message
		while (bytesRecv != atoi(messageSize)){
			int temp = bytesRecv;
			bytesRecv = recv(connection, tempMessage, MSGRECVLENGTH, 0) + bytesRecv; //Grab incoming message
			for (int i = 0; i < bytesRecv - temp; i++){
				if (isprint(tempMessage[i])){
					msgRecv[temp + i] = tempMessage[i];
				}
			}
		}
		for (int i = 4; i<atoi(messageSize); i++){
			if (i<8){
				messageType[i - 4] = msgRecv[i];
			}
			else
				message[i - 8] = msgRecv[i];

		}
		if (strncmp(messageType, "USER", 4) == 0){
			strcpy(name, message);
			//Unsure if I need to include payload size
			payload = (int)strlen(userName);
			int totalMessageLength = payload + headerLength + 1;				char c_messageLength[4];
			//convert length to ascii
			sprintf(c_messageLength, "%d", totalMessageLength);
			char *pTempArray = convertTo3ByteString(c_messageLength);;
			char fullMessage[169];

			strcpy(message, pTempArray);
			strcat(message, " ACPT ");
			strcat(message, userName);
			strcat(message, "\0");
			payload = (int)strlen(message);

			printf("User %s connected\n", name);
			if (send(connection, message, (int)strlen(message), 0) < 0)		//send ACPT reply
			{
				printf("Error sending message");
			}
		}
		else if (strncmp(messageType, "ILVU", 4) == 0){
			strcpy(name, "local");
			local = 1;
			strcpy(message, "008 IKNW");				//Unsure if I need to include payload size
			if (send(connection, message, (int)strlen(message), 0) < 0)	//attempt to send reply
			{
				printf("Error sending message");
			}
		}
		else if (strncmp(messageType, "TEXT", 4) == 0){
			int i = 0;
			while (name[i]>0 && name[i]<255){
				cout << name[i];
				i++;
			}
			cout << ":";
			i = 0;
			while (message[i]>0 && message[i]<255){
				cout << message[i];
				i++;
			}
			cout << "\n";




			//need to do some calculation with payload in order to handle the text
		}
		else if (strncmp(messageType, "QUIT", 4) == 0){
			quit = 1;
		}
		else if (strncmp(messageType, "KYLO", 4) == 0){
			kylo = 1;
			closesocket(connection);
			exit(0);
		}
		else{
			//do nothing we recieved garbage...
		}
	}
	closesocket(connection);
	return;

}

//converts string to 3 byte length by adding leading zeros as necessary to get length of 3
char * convertTo3ByteString(char c_payloadLength[])
{
	int numOfBytes = strlen(c_payloadLength);
	char tempArray[4];
	switch (numOfBytes)
	{
		//if the num of bytes is 1, add two leading zeros to make it 3
	case 1:
		strcpy(tempArray, "00");
		strcat(tempArray, c_payloadLength);
		break;
		//if the num of bytes is 2, add 1 leading zero to make it 3
	case 2:
		strcpy(tempArray, "0");
		strcat(tempArray, c_payloadLength);
		break;
		//if the num of bytes is 3, copy string as is because it is already 3 bytes
	case 3:
		strcpy(tempArray, c_payloadLength);
		break;
	}
	return tempArray;
}
